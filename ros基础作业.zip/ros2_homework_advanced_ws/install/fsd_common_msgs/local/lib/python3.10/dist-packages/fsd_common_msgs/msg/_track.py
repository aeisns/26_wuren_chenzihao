# generated from rosidl_generator_py/resource/_idl.py.em
# with input from fsd_common_msgs:msg/Track.idl
# generated code does not contain a copyright notice


# Import statements for member types

import builtins  # noqa: E402, I100

import rosidl_parser.definition  # noqa: E402, I100


class Metaclass_Track(type):
    """Metaclass of message 'Track'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('fsd_common_msgs')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'fsd_common_msgs.msg.Track')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__msg__track
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__msg__track
            cls._CONVERT_TO_PY = module.convert_to_py_msg__msg__track
            cls._TYPE_SUPPORT = module.type_support_msg__msg__track
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__msg__track

            from geometry_msgs.msg import Point
            if Point.__class__._TYPE_SUPPORT is None:
                Point.__class__.__import_type_support__()

            from std_msgs.msg import Header
            if Header.__class__._TYPE_SUPPORT is None:
                Header.__class__.__import_type_support__()

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class Track(metaclass=Metaclass_Track):
    """Message class 'Track'."""

    __slots__ = [
        '_header',
        '_cones_left',
        '_cones_right',
        '_cones_orange',
        '_cones_orange_big',
        '_tk_device_start',
        '_tk_device_end',
    ]

    _fields_and_field_types = {
        'header': 'std_msgs/Header',
        'cones_left': 'sequence<geometry_msgs/Point>',
        'cones_right': 'sequence<geometry_msgs/Point>',
        'cones_orange': 'sequence<geometry_msgs/Point>',
        'cones_orange_big': 'sequence<geometry_msgs/Point>',
        'tk_device_start': 'sequence<geometry_msgs/Point>',
        'tk_device_end': 'sequence<geometry_msgs/Point>',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.NamespacedType(['std_msgs', 'msg'], 'Header'),  # noqa: E501
        rosidl_parser.definition.UnboundedSequence(rosidl_parser.definition.NamespacedType(['geometry_msgs', 'msg'], 'Point')),  # noqa: E501
        rosidl_parser.definition.UnboundedSequence(rosidl_parser.definition.NamespacedType(['geometry_msgs', 'msg'], 'Point')),  # noqa: E501
        rosidl_parser.definition.UnboundedSequence(rosidl_parser.definition.NamespacedType(['geometry_msgs', 'msg'], 'Point')),  # noqa: E501
        rosidl_parser.definition.UnboundedSequence(rosidl_parser.definition.NamespacedType(['geometry_msgs', 'msg'], 'Point')),  # noqa: E501
        rosidl_parser.definition.UnboundedSequence(rosidl_parser.definition.NamespacedType(['geometry_msgs', 'msg'], 'Point')),  # noqa: E501
        rosidl_parser.definition.UnboundedSequence(rosidl_parser.definition.NamespacedType(['geometry_msgs', 'msg'], 'Point')),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        from std_msgs.msg import Header
        self.header = kwargs.get('header', Header())
        self.cones_left = kwargs.get('cones_left', [])
        self.cones_right = kwargs.get('cones_right', [])
        self.cones_orange = kwargs.get('cones_orange', [])
        self.cones_orange_big = kwargs.get('cones_orange_big', [])
        self.tk_device_start = kwargs.get('tk_device_start', [])
        self.tk_device_end = kwargs.get('tk_device_end', [])

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.header != other.header:
            return False
        if self.cones_left != other.cones_left:
            return False
        if self.cones_right != other.cones_right:
            return False
        if self.cones_orange != other.cones_orange:
            return False
        if self.cones_orange_big != other.cones_orange_big:
            return False
        if self.tk_device_start != other.tk_device_start:
            return False
        if self.tk_device_end != other.tk_device_end:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def header(self):
        """Message field 'header'."""
        return self._header

    @header.setter
    def header(self, value):
        if __debug__:
            from std_msgs.msg import Header
            assert \
                isinstance(value, Header), \
                "The 'header' field must be a sub message of type 'Header'"
        self._header = value

    @builtins.property
    def cones_left(self):
        """Message field 'cones_left'."""
        return self._cones_left

    @cones_left.setter
    def cones_left(self, value):
        if __debug__:
            from geometry_msgs.msg import Point
            from collections.abc import Sequence
            from collections.abc import Set
            from collections import UserList
            from collections import UserString
            assert \
                ((isinstance(value, Sequence) or
                  isinstance(value, Set) or
                  isinstance(value, UserList)) and
                 not isinstance(value, str) and
                 not isinstance(value, UserString) and
                 all(isinstance(v, Point) for v in value) and
                 True), \
                "The 'cones_left' field must be a set or sequence and each value of type 'Point'"
        self._cones_left = value

    @builtins.property
    def cones_right(self):
        """Message field 'cones_right'."""
        return self._cones_right

    @cones_right.setter
    def cones_right(self, value):
        if __debug__:
            from geometry_msgs.msg import Point
            from collections.abc import Sequence
            from collections.abc import Set
            from collections import UserList
            from collections import UserString
            assert \
                ((isinstance(value, Sequence) or
                  isinstance(value, Set) or
                  isinstance(value, UserList)) and
                 not isinstance(value, str) and
                 not isinstance(value, UserString) and
                 all(isinstance(v, Point) for v in value) and
                 True), \
                "The 'cones_right' field must be a set or sequence and each value of type 'Point'"
        self._cones_right = value

    @builtins.property
    def cones_orange(self):
        """Message field 'cones_orange'."""
        return self._cones_orange

    @cones_orange.setter
    def cones_orange(self, value):
        if __debug__:
            from geometry_msgs.msg import Point
            from collections.abc import Sequence
            from collections.abc import Set
            from collections import UserList
            from collections import UserString
            assert \
                ((isinstance(value, Sequence) or
                  isinstance(value, Set) or
                  isinstance(value, UserList)) and
                 not isinstance(value, str) and
                 not isinstance(value, UserString) and
                 all(isinstance(v, Point) for v in value) and
                 True), \
                "The 'cones_orange' field must be a set or sequence and each value of type 'Point'"
        self._cones_orange = value

    @builtins.property
    def cones_orange_big(self):
        """Message field 'cones_orange_big'."""
        return self._cones_orange_big

    @cones_orange_big.setter
    def cones_orange_big(self, value):
        if __debug__:
            from geometry_msgs.msg import Point
            from collections.abc import Sequence
            from collections.abc import Set
            from collections import UserList
            from collections import UserString
            assert \
                ((isinstance(value, Sequence) or
                  isinstance(value, Set) or
                  isinstance(value, UserList)) and
                 not isinstance(value, str) and
                 not isinstance(value, UserString) and
                 all(isinstance(v, Point) for v in value) and
                 True), \
                "The 'cones_orange_big' field must be a set or sequence and each value of type 'Point'"
        self._cones_orange_big = value

    @builtins.property
    def tk_device_start(self):
        """Message field 'tk_device_start'."""
        return self._tk_device_start

    @tk_device_start.setter
    def tk_device_start(self, value):
        if __debug__:
            from geometry_msgs.msg import Point
            from collections.abc import Sequence
            from collections.abc import Set
            from collections import UserList
            from collections import UserString
            assert \
                ((isinstance(value, Sequence) or
                  isinstance(value, Set) or
                  isinstance(value, UserList)) and
                 not isinstance(value, str) and
                 not isinstance(value, UserString) and
                 all(isinstance(v, Point) for v in value) and
                 True), \
                "The 'tk_device_start' field must be a set or sequence and each value of type 'Point'"
        self._tk_device_start = value

    @builtins.property
    def tk_device_end(self):
        """Message field 'tk_device_end'."""
        return self._tk_device_end

    @tk_device_end.setter
    def tk_device_end(self, value):
        if __debug__:
            from geometry_msgs.msg import Point
            from collections.abc import Sequence
            from collections.abc import Set
            from collections import UserList
            from collections import UserString
            assert \
                ((isinstance(value, Sequence) or
                  isinstance(value, Set) or
                  isinstance(value, UserList)) and
                 not isinstance(value, str) and
                 not isinstance(value, UserString) and
                 all(isinstance(v, Point) for v in value) and
                 True), \
                "The 'tk_device_end' field must be a set or sequence and each value of type 'Point'"
        self._tk_device_end = value
