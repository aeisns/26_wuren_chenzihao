#include "rclcpp/rclcpp.hpp"
#include "geometry_msgs/msg/twist.hpp"
#include <chrono>
#include <cmath>

using namespace std::chrono_literals;

class EightTurtleNode : public rclcpp::Node
{
public:
  EightTurtleNode() : Node("eight_turtle_cpp_node")
  {
    // 从yaml声明并读取三个参数
    this->declare_parameter<double>("linear_vel",0.2);
    this->declare_parameter<double>("angular_vel",0.4);
    
    linear_ = this->get_parameter("linear_vel").as_double();
    angular_ = this->get_parameter("angular_vel").as_double();
    // 创建速度话题发布者
    pub_ = this->create_publisher<geometry_msgs::msg::Twist>("/turtle1/cmd_vel",10);
    // 50ms定时执行一次回调
    timer_ = this->create_wall_timer(50ms,std::bind(&EightTurtleNode::timer_cb,this));
    start_time_ = this->now().seconds();
  }

private:
  void timer_cb()
  {
    static double run_t = 0.0;
    run_t += 0.05;
    // 单圈跑完需要的时间
    double one_circle_time = 2 * M_PI / angular_;

    geometry_msgs::msg::Twist vel_msg;
    vel_msg.linear.x = linear_;

    // 算跑了几个整圈，偶数圈正转、奇数圈反转
    int circle_num = floor(run_t / one_circle_time);
    if(circle_num % 2 == 0)
        vel_msg.angular.z = angular_;
    else
        vel_msg.angular.z = -angular_;

    pub_->publish(vel_msg);
  }

  rclcpp::Publisher<geometry_msgs::msg::Twist>::SharedPtr pub_;
  rclcpp::TimerBase::SharedPtr timer_;
  double linear_,angular_,start_time_;
};

int main(int argc,char **argv)
{
  rclcpp::init(argc,argv);
  auto node = std::make_shared<EightTurtleNode>();
  rclcpp::spin(node);
  rclcpp::shutdown();
  return 0;
}
