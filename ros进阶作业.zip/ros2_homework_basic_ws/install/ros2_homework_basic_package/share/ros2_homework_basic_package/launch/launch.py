from launch import LaunchDescription
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory
import os

def generate_launch_description():
    yaml_path = os.path.join(get_package_share_directory("ros2_homework_basic_package"),"config","param.yaml")
    return LaunchDescription([
        Node(package="turtlesim",executable="turtlesim_node"),
        Node(package="ros2_homework_basic_package",executable="turtle",parameters=[yaml_path])
    ])
